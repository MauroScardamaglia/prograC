package modelo;

public class SaludoState extends AbstractState 
{

	public SaludoState(Soldado soldado)
	{
		super(soldado);
		// TODO Auto-generated constructor stub
	}

	@Override
	public void volvePatrullar()
	{
		this.soldado.setEstado(new PatrullaState(this.soldado));
		}

	@Override
	public void haySospechas()
	{
	this.soldado.setEstado(new SospechaState(this.soldado));
	
	}

	@Override
	public void hayEvidencia()
	{this.soldado.setEstado(new AtaqueState(this.soldado));
	
	}

	@Override
	public void saludaSuperior()
	{
		System.out.println("YA estoy saludando");
	}

	@Override
	public void recibeDanoLetal()
	{this.soldado.setEstado(new MuertoState(this.soldado));
	}

	@Override
	public void actua()
	{
		System.out.println(this.soldado.getName()+" SALUDANDO");
	}

}

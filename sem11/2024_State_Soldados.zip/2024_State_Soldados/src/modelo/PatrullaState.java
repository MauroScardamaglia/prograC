package modelo;

public class PatrullaState extends AbstractState 
{

	public PatrullaState(Soldado soldado)
	{
		super(soldado);
		// TODO Auto-generated constructor stub
	}

	@Override
	public void volvePatrullar()
	{
	System.out.println(this.soldado.getName()+" YA esta patrullando");
	}

	@Override
	public void haySospechas()
	{
	this.soldado.setEstado(new SospechaState(this.soldado));
	
	}

	@Override
	public void hayEvidencia()
	{
		this.soldado.setEstado(new AtaqueState(this.soldado));
		
	}

	@Override
	public void saludaSuperior()
	{
		this.soldado.setEstado(new SaludoState(this.soldado));
		

	}

	@Override
	public void recibeDanoLetal()
	{
		this.soldado.setEstado(new MuertoState(this.soldado));
		

	}

	@Override
	public void actua()
	{
		System.out.println(this.soldado.getName()+" esta Patrullando");
	}

}

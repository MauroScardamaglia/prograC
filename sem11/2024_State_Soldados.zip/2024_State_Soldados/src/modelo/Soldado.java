package modelo;

import util.Util;

public class Soldado extends Thread
{
	private IState estado = new PatrullaState(this);

	public Soldado(String nombre)
	{
		super(nombre);
	}

	public void volvePatrullar()
	{
		this.estado.volvePatrullar();
	}

	public void haySospechas()
	{
		this.estado.haySospechas();
	}

	public void hayEvidencia()
	{
		this.estado.hayEvidencia();
	}

	public void saludaSuperior()
	{
		this.estado.saludaSuperior();
	}

	public void recibeDanoLetal()
	{
		this.estado.recibeDanoLetal();
	}

	public void actua()
	{
		this.estado.actua();
	}

	public void setEstado(IState estado)
	{
		this.estado = estado;
	}

	@Override
	public void run()
	{
		while (true)
		{
			Util.espera();
			this.actua();
		}
	}

}

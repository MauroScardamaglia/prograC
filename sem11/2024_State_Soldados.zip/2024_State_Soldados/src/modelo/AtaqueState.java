package modelo;

public class AtaqueState extends AbstractState 
{

	public AtaqueState(Soldado soldado)
	{
		super(soldado);
		// TODO Auto-generated constructor stub
	}

	@Override
	public void volvePatrullar()
	{
	System.out.println(this.soldado.getName()+" NO PUEDO PATRULLAR, estoy atacando");
	}

	@Override
	public void haySospechas()
	{
		System.out.println(this.soldado.getName()+" NO PUEDO SOSPECHAR, estoy atacando");
		
	}

	@Override
	public void hayEvidencia()
	{
		System.out.println("YA estoy atacando");
	}

	@Override
	public void saludaSuperior()
	{
		System.out.println(this.soldado.getName()+" NO PUEDO SALUDAR, estoy atacando");
		
	}

	@Override
	public void recibeDanoLetal()
	{
	this.soldado.setEstado(new MuertoState(this.soldado));
	}

	@Override
	public void actua()
	{
		System.out.println(this.soldado.getName()+" ATACA");		
	}

}

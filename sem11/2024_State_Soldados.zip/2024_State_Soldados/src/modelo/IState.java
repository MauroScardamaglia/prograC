package modelo;

public interface IState
{
void volvePatrullar();
void haySospechas();
void hayEvidencia();
void saludaSuperior();
void recibeDanoLetal();

void actua();
}

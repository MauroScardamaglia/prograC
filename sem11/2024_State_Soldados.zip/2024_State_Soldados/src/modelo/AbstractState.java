package modelo;

public abstract class AbstractState implements IState
{
	protected Soldado soldado;

	public AbstractState(Soldado soldado)
	{
		this.soldado = soldado;
	}

}

package modelo;

public class SospechaState extends AbstractState
{

	public SospechaState(Soldado soldado)
	{
		super(soldado);
		// TODO Auto-generated constructor stub
	}

	@Override
	public void volvePatrullar()
	{
		this.soldado.setEstado(new PatrullaState(this.soldado));
	}

	@Override
	public void haySospechas()
	{
		System.out.println("YA estoy sospechando");
	}

	@Override
	public void hayEvidencia()
	{
		this.soldado.setEstado(new AtaqueState(this.soldado));

	}

	@Override
	public void saludaSuperior()
	{
		System.out.println("NO puedo, estoy sospechando");
	}

	@Override
	public void recibeDanoLetal()
	{
		this.soldado.setEstado(new MuertoState(this.soldado));
	}

	@Override
	public void actua()
	{
	System.out.println(this.soldado.getName()+" esta sospechando algo raro");
	}

}

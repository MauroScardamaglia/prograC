package modelo;

public class MuertoState extends AbstractState 
{

	public MuertoState(Soldado soldado)
	{
		super(soldado);
		// TODO Auto-generated constructor stub
	}

	@Override
	public void volvePatrullar()
	{
	System.out.println(this.soldado.getName()+" YA esta MUERTO");
	}

	@Override
	public void haySospechas()
	{
		System.out.println(this.soldado.getName()+" YA esta MUERTO");
	}

	@Override
	public void hayEvidencia()
	{
		System.out.println(this.soldado.getName()+" YA esta MUERTO");
	}

	@Override
	public void saludaSuperior()
	{System.out.println(this.soldado.getName()+" YA esta MUERTO");
	}

	@Override
	public void recibeDanoLetal()
	{System.out.println(this.soldado.getName()+" YA esta MUERTO");
	}

	@Override
	public void actua()
	{
	}

}

package vista;

import java.awt.EventQueue;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;

import modelo.Soldado;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;

public class Ventana extends JFrame implements ActionListener
{
    private JPanel contentPane;
    private JPanel panel;
    private JPanel panel_1;
    private JButton btnPatrullar;
    private JPanel panel_2;
    private JButton btnSaludar;
    private JPanel panel_3;
    private JButton btnSospechar;
    private JPanel panel_4;
    private JButton btnAtacar;
    private JPanel panel_5;
    private JButton btnMorir;
    private Soldado soldado = new Soldado("Ryan");
    private JPanel panel_6;
    private JScrollPane scrollPane;
    private JTextArea textArea;

    /**
     * Launch the application.
     */
    public static void main(String[] args)
    {
	EventQueue.invokeLater(new Runnable()
	{
	    public void run()
	    {
		try
		{
		    Ventana frame = new Ventana();
		    frame.setVisible(true);
		} catch (Exception e)
		{
		    e.printStackTrace();
		}
	    }
	});
    }

    /**
     * Create the frame.
     */
    public Ventana()
    {
	this.soldado.start();
	setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
	setBounds(100, 100, 450, 300);
	this.contentPane = new JPanel();
	this.contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
	setContentPane(this.contentPane);
	this.contentPane.setLayout(new GridLayout(2, 0, 0, 0));
	
	this.scrollPane = new JScrollPane();
	this.contentPane.add(this.scrollPane);
	
	this.textArea = new JTextArea();
	this.scrollPane.setViewportView(this.textArea);
	
	this.panel_6 = new JPanel();
	this.contentPane.add(this.panel_6);

	this.panel_1 = new JPanel();
	this.panel_6.add(this.panel_1);

	this.btnPatrullar = new JButton("Patrullar");
	this.btnPatrullar.addActionListener(this);
	this.panel_1.add(this.btnPatrullar);

	this.panel_2 = new JPanel();
	this.panel_6.add(this.panel_2);

	this.btnSaludar = new JButton("Saludar");
	this.btnSaludar.addActionListener(this);
	this.panel_2.add(this.btnSaludar);

	this.panel_3 = new JPanel();
	this.panel_6.add(this.panel_3);

	this.btnSospechar = new JButton("Sospechar");
	this.btnSospechar.addActionListener(this);
	this.panel_3.add(this.btnSospechar);

	this.panel_4 = new JPanel();
	this.panel_6.add(this.panel_4);

	this.btnAtacar = new JButton("Atacar");
	this.btnAtacar.addActionListener(this);
	this.panel_4.add(this.btnAtacar);

	this.panel_5 = new JPanel();
	this.panel_6.add(this.panel_5);

	this.btnMorir = new JButton("Morir");
	this.btnMorir.addActionListener(this);
	this.panel_5.add(this.btnMorir);

    }

    public void actionPerformed(ActionEvent e)
    {
	if (e.getSource() == this.btnMorir)
	{
	    do_btnMorir_actionPerformed(e);
	}
	if (e.getSource() == this.btnAtacar)
	{
	    do_btnAtacar_actionPerformed(e);
	}
	if (e.getSource() == this.btnSospechar)
	{
	    do_btnSospechar_actionPerformed(e);
	}
	if (e.getSource() == this.btnSaludar)
	{
	    do_btnSaludar_actionPerformed(e);
	}
	if (e.getSource() == this.btnPatrullar)
	{
	    do_btnPatrullar_actionPerformed(e);
	}
    }

    protected void do_btnPatrullar_actionPerformed(ActionEvent e)
    {
	this.soldado.volvePatrullar();
    }

    protected void do_btnSaludar_actionPerformed(ActionEvent e)
    {
	this.soldado.saludaSuperior();
    }

    protected void do_btnSospechar_actionPerformed(ActionEvent e)
    {
	this.soldado.haySospechas();
    }

    protected void do_btnAtacar_actionPerformed(ActionEvent e)
    {
	this.soldado.hayEvidencia();
    }

    protected void do_btnMorir_actionPerformed(ActionEvent e)
    {
	this.soldado.recibeDanoLetal();
    }
    public void agregarTexto(String texto) 
    {
    	this.textArea.append(texto+"\n");
    	
    }
}
